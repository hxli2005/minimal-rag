# 运行指南

Python 3.12＋。核心命令只有 `demo`、`index`、`search`、`ask`。`ask` 和所有 benchmark 的当前入口共用纯 BM25 的 `IndexedKnowledgeBase`、`search/read` 工具、模型适配器和核心循环。

## 安装与离线演示

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -e .
.venv/bin/python -m minimal_rag demo
```

`demo` 从 `fixtures/retail.jsonl` 建 SQLite 索引，回放预先写好的模型决策，生成调用为 0，无需账号。

## 自己的资料与真实问答

JSONL 每行包含 `id`、`title`、`text`、`source`。SQLite FTS5 索引保留原文和字符位置；构建器拒绝覆盖已有文件。

```bash
.venv/bin/python -m minimal_rag index examples/documents.jsonl --output data/example.sqlite
.venv/bin/python -m minimal_rag search --index data/example.sqlite --query "connection timeout"
.venv/bin/python -m pip install -e '.[codex]'
.venv/bin/python -m minimal_rag ask --live --index data/example.sqlite \
  --question "How should I investigate a connection timeout?" --max-turns 4
```

`ask --live` 使用现有 ChatGPT 登录，会发送检索到的原文并消耗用量；`--max-turns` 限制外层调用次数。模型自主决定搜索词、文档内搜索、翻页和继续读取；主实现不加载向量模型、重排或标题预览。5 篇原文的小例子见 [examples/sol-demo](../examples/sol-demo/README.md)。

## 当前 benchmark

```bash
.venv/bin/python -m pip install -e '.[codex,benchmarks]' -e ./experiments
.venv/bin/python -m minimal_rag_experiments.benchmark --dataset enterprise \
  --split test --live --output runs/bm25-enterprise
```

`--dataset` 支持 `enterprise`、`financebench`、`hotpotqa`、`browsecomp`。前三者使用现有 `data/benchmarks/<dataset>/{dev,test}.json`，BrowseComp 使用冻结的 dev100／剩余730；完整830可合并两个不重叠输出目录。Enterprise、FinanceBench、BrowseComp 读取完整 `corpus.sqlite`；HotpotQA distractor 按官方任务提供的每题10篇文档建同一种 BM25 索引。数据准备仍用 `scripts/prepare_rag_benchmarks.py`、`scripts/index_rag_benchmarks.py`；BrowseComp 下载建库入口保留在对应日期实验目录。

生成统一用 sol high 和当前提示。前三者保留4000字符摘录／12轮，BrowseComp 保留2000字符／30轮；搜索排名和工具实现完全相同。每题只生成一次，支持同配置 `--resume`，中断记录不会自动重新抽答案。冒烟用 `--split dev --limit 1`，test 始终运行完整题集。默认生成并发5、裁判并发1，可以分别指定。

Enterprise、FinanceBench 使用原有 sol medium 裁判；HotpotQA 使用官方 EM/F1。BrowseComp 写出 `official/` 下的官方格式答案，`retrieved_docids` 只统计 search 返回；再交给固定的官方脚本＋Qwen3-32B BF16判分，生成完成本身不代表判分完成。所有输出包含逐题轨迹、配置、请求计数和汇总；历史成绩不会自动成为当前实现成绩。

历史混合检索已移入 `minimal_rag_experiments.hybrid_rag`，需要时安装 `pip install -e './experiments[historical]'`。`rag_optimization_eval`、日期目录的冻结 runner 及 `experiments/scripts/` 下的模型准备、dense 建库脚本只用于历史实验，当前 benchmark 不加载它们。历史成绩与新评测结果分栏见[实验索引](../experiments/README.md)。

2026-10-17 独立向量工具实验已按用户要求终止并[归档](../experiments/semantic-tool-20261016/archive.json)。`semantic_search`和`--semantic-url`不再是当前入口；归档代码、向量分片和云端快照仅保留作历史记录，不自动恢复运行。

## 可选文件工具开发对照

`minimal_rag.file_tools.CorpusFiles`现在只提供Grep，使用ripgrep和完整原文文件视图；`files.tools(kb)`得到search/read/Grep。独立Glob和按行Read已删除，原有按字符read保留。Grep只访问导出的`/corpus`视图，沿用成熟接口的参数名；其中`glob`仍是Grep原生的文件过滤参数，不是另一个工具。默认CLI与benchmark工具集仍保持原样。

Enterprise dev100原三工具对照74→78/100只属于历史版本，其runner使用冻结副本，见[旧协议](../experiments/code-tools-20261017/brief.md)。当前仅Grep的跨基准小样本入口见[BrowseComp dev30协议](../experiments/grep-browsecomp-20261017/brief.md)。复跑应使用新的输出目录；已有目录只允许同配置`--resume`，不会重新生成已有答案。

仅Grep的BrowseComp dev30对照已完成：A/B均28/30，输入token下降但没有正确率提升，因此仍为可选候选，详见[报告](../experiments/reports/grep-browsecomp-20261017.md)。

```bash
.venv/bin/python experiments/grep-browsecomp-20261017/run.py --live \
  --files data/benchmarks/browsecomp-plus/grep-files \
  --output runs/grep-browsecomp-new
```

## 测试

```bash
.venv/bin/python -m pip install -e '.[test,codex]' -e './experiments[test]'
.venv/bin/python -m pytest -q tests experiments/tests
```

实验包 `experiments/` 保存评测器、检索变体和各轮实验入口，核心包不导入它。各轮实验的运行命令写在对应日期目录的 brief 或 notes 中；复现历史成绩要从对应提交出发，当前代码不等于当时执行的版本。`data/`、`models/`、`runs/` 被 Git 忽略，保存语料、模型和原始运行材料。
