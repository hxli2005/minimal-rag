import pytest

from minimal_rag.indexed_rag import IndexedKnowledgeBase, indexed_tools
from minimal_rag import semantic_search


@pytest.mark.asyncio
async def test_semantic_search_preserves_original_prefix_and_server_pagination(tmp_path, monkeypatch):
    path = tmp_path / "corpus.sqlite"
    IndexedKnowledgeBase.build(path, [{"id": "D", "title": "Manual", "text": "Original text after prefix.", "source": "test://D"}])
    def remote(endpoint, payload):
        assert payload == {"corpus": "enterprise", "query": "meaning", "limit": 1, "offset": 3}
        return {"hits": [{"document_id": "D", "score": 0.75}], "next_offset": 4}
    monkeypatch.setattr(semantic_search, "request", remote)
    kb = IndexedKnowledgeBase(path, excerpt_chars=8)
    try:
        before = kb.search("Original")
        tool = semantic_search.semantic_tool(kb, "http://localhost:8765", "enterprise")
        result = await tool.execute(query="meaning", limit=1, offset=3)
        assert result == {"hits": [{"document_id": "D", "title": "Manual", "text": "Original",
                                    "offset": 0, "document_chars": 27, "truncated": True,
                                    "source": "test://D", "score": 0.75}], "next_offset": 4}
        assert kb.search("Original") == before
        assert set(indexed_tools(kb)) == {"search", "read"}
    finally:
        kb.close()
