"""Optional document-level vector search; BM25 and the agent loop are unchanged."""
import asyncio
import json
from urllib.request import Request, urlopen

from minimal_rag.indexed_rag import SearchArgs
from minimal_rag.loop import Tool


DESCRIPTION = (
    "Search whole documents by meaning. When the original wording may differ from the question, "
    "describe the information you need in natural language. Each document is represented only by "
    "its first approximately 4096 tokens; find later details with read or search with scope set to "
    "the document ID. Hits contain the beginning of the original document, character offsets, "
    "document length and a similarity score. limit/offset paginate ranked documents."
)


def request(endpoint, payload):
    req = Request(endpoint.rstrip("/") + "/search", json.dumps(payload).encode(),
                  {"Content-Type": "application/json"})
    with urlopen(req, timeout=120) as response:
        return json.load(response)


def semantic_tool(kb, endpoint, corpus):
    async def search(query, limit=5, offset=0):
        result = await asyncio.to_thread(request, endpoint,
                                         {"corpus": corpus, "query": query, "limit": limit, "offset": offset})
        hits = []
        for hit in result["hits"]:
            doc = kb.read(hit["document_id"], offset=0, limit=kb.excerpt_chars)
            if "error" in doc:
                raise ValueError("semantic index returned a document absent from the local corpus")
            doc.pop("next_offset")
            doc.update(truncated=len(doc["text"]) < doc["document_chars"], score=hit["score"])
            hits.append(doc)
        return {"hits": hits, "next_offset": result["next_offset"]}

    return Tool(DESCRIPTION, SearchArgs, search)
